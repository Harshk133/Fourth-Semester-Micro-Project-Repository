public class Program {

}
